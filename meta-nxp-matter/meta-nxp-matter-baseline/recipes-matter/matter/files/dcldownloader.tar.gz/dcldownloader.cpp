#include <cstdio>
#include <curl/curl.h>
#include <openssl/x509.h>
#include <openssl/x509v3.h> 
#include <openssl/pem.h>
#ifdef __x86_64__
#include <jsoncpp/json/json.h>
#else
#include <json/json.h>
#endif
#include <fstream>
#include <sstream>
#include <iostream>
#include <sys/stat.h>
#include <regex>

#define PAADIR "/etc/dcl_paas"

const char* PRODUCTION_NODE_URL_REST = "https://on.dcl.csa-iot.org";  

size_t writeCallback(void *contents, size_t size, size_t nmemb, std::string *writerData) {
    ((std::string*)writerData)->append((char*)contents, size * nmemb);
    return size * nmemb;
}

void parsePaaRootCerts(std::string& json, std::vector<std::map<std::string, std::string>>& paaList) {
    Json::Value root;  
    Json::Reader reader;
    reader.parse(json, root);

    for(auto& cert : root["approvedRootCertificates"]["certs"]) {
        std::map<std::string, std::string> item;
        item["subject"] = cert["subject"].asString();
        item["subjectKeyId"] = cert["subjectKeyId"].asString(); 
        paaList.push_back(item);
    }
}

void fetchCertsOverHttp(const std::string& url, std::string& cert, std::string& subject) {

    CURL* curl = curl_easy_init();
    std::string response;

    curl_easy_setopt(curl, CURLOPT_URL, url.c_str());
    curl_easy_setopt(curl, CURLOPT_WRITEFUNCTION, writeCallback);
    curl_easy_setopt(curl, CURLOPT_WRITEDATA, &response);

    CURLcode result = curl_easy_perform(curl);
    if (result == CURLE_OK) {
        // Parse response to get cert and subject
        Json::Value root;
        Json::Reader reader;
        reader.parse(response, root);

        cert = root["approvedCertificates"]["certs"][0]["pemCert"].asString();
        subject = root["approvedCertificates"]["certs"][0]["subjectAsText"].asString();
    }

    curl_easy_cleanup(curl);
}

void writePaaRootCert(const std::string& cert, const std::string& subject, std::string path) {

    std::string filename;
    filename.append(path.c_str());
    filename.append("/dcld_mirror_");
    std::regex pattern("[^a-zA-Z0-9_-]");
    std::string subject2;
    subject2 = std::regex_replace(subject, pattern, "");

    std::regex pattern2("[=, ]");
    subject2 = std::regex_replace(subject2, pattern2, "_");
    filename.append(subject2);

    // Write PEM cert to file

    std::ofstream ofile(filename + ".pem");
    ofile << cert;
    ofile.close();

    // Convert to DER format
    // PEM to DER conversion

    BIO* pemBio = BIO_new_mem_buf(cert.c_str(), cert.size());

    X509* x509 = PEM_read_bio_X509(pemBio, NULL, NULL, NULL); 

    unsigned char* derCert = NULL;
    int derLen = i2d_X509(x509, &derCert);

    std::ofstream ofileDer(filename + ".der", std::ios::binary);
    ofileDer.write((char*)derCert, derLen);

    // Cleanup
    OPENSSL_free(derCert); 
    X509_free(x509);
    BIO_free(pemBio);
}


int main(int argc, char *argv[]) {

    std::string path;
    if (argc == 1)
        path = PAADIR;
    else
        path = argv[1];
    struct stat info;
    if (stat(path.c_str(), &info) != 0) {
        // Directory doesn't exist, create it
        if (mkdir(path.c_str(), 0700) != 0) {
            // Error handling 
            std::cout << "Failed to create paas folder!\n";
            return -1;
        }
    }
    printf("Querying DCL list...");
    fflush(stdout);

    std::string restUrl = PRODUCTION_NODE_URL_REST;

    std::vector<std::map<std::string, std::string>> paaList;

    // Fetch all certificates over HTTP
    // and parse into paaList

    std::string url = restUrl + "/dcl/pki/root-certificates";

    CURL* curl = curl_easy_init();
    std::string response;

    curl_easy_setopt(curl, CURLOPT_URL, url.c_str());
    curl_easy_setopt(curl, CURLOPT_WRITEFUNCTION, writeCallback);
    curl_easy_setopt(curl, CURLOPT_WRITEDATA, &response);

    CURLcode result = curl_easy_perform(curl);
    if (result == CURLE_OK) {
        parsePaaRootCerts(response, paaList);
    } else {
        printf("Failed!!\n");
        fprintf(stderr, "curl_easy_perform() failed: %s\n",
                curl_easy_strerror(result));
        return -1;
    }
    printf("Done\n");

    curl_easy_cleanup(curl);

    int completed = 0;
    int total = paaList.size();

    for (auto& paa : paaList) {
        std::string cert, subject;

        std::stringstream ss;
        ss << restUrl << "/dcl/pki/certificates/" << paa["subject"] << "/" << paa["subjectKeyId"];
        std::string url = ss.str();
        fetchCertsOverHttp(url, cert, subject); 

        writePaaRootCert(cert, subject, path);
        completed++;

        int progress = completed * 100 / total; 
        printf("\r[%-50s] %d%%", 
                std::string(progress/2, '#').c_str(), progress); 
        fflush(stdout);
    }

    printf("\n");

    return 0;
}
